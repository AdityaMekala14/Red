"""Behavior tests for kempt commands against a real temp repo."""

from __future__ import annotations

import subprocess
from pathlib import Path

from kempt.commands import lint_commits, health, changelog, toc
from kempt import gitutil


def _git(repo: Path, *args: str) -> str:
    return subprocess.run(
        ["git", *args], cwd=repo, capture_output=True, text=True, check=True
    ).stdout.strip()


def test_lint_flags_nonconventional_commit(repo):
    violations = lint_commits.lint(None, cwd=repo)
    subjects = [v[1] for v in violations]
    assert any("without convention" in s for s in subjects)
    # The conventional feat commit should not be flagged.
    assert not any(s.startswith("feat:") for s in subjects)


def test_lint_clean_history_passes(repo):
    # Amend the bad commit to be conventional.
    _git(repo, "commit", "--amend", "-q", "-m", "chore: add app entrypoint")
    assert lint_commits.lint(None, cwd=repo) == []


def test_health_scores_and_detects_missing(repo):
    r = health.check(cwd=repo)
    labels = {c["label"]: c["present"] for c in r["checks"]}
    assert labels["README"] is True
    assert labels["LICENSE"] is False  # none in the sample repo
    assert 0 <= r["score"] <= r["total"]


def test_changelog_groups_features(repo):
    out = changelog.build(None, cwd=repo)
    assert "Features" in out
    assert "initial project scaffold" in out


def test_toc_extracts_and_is_idempotent(tmp_path):
    md = "# Title\n\n## Install\n\n## Usage\n\n### Flags\n"
    headings = toc.extract_headings(md)
    assert ("## ".count("#"), "Install") != headings  # sanity
    assert (2, "Install") in headings and (3, "Flags") in headings

    rendered = toc.render_toc(headings, 2)
    assert "- [Install](#install)" in rendered
    assert "  - [Flags](#flags)" in rendered

    once = toc.apply_toc(md, rendered)
    twice = toc.apply_toc(once, rendered)
    assert once == twice  # idempotent


def test_toc_code_fence_ignored():
    md = "## Real\n\n```\n## NotAHeading\n```\n"
    headings = toc.extract_headings(md)
    assert (2, "Real") in headings
    assert all("NotAHeading" not in h[1] for h in headings)


def test_gitutil_default_branch(repo):
    assert gitutil.default_branch(cwd=repo) == "main"
