"""Shared fixtures: build a throwaway git repo to run commands against."""

from __future__ import annotations

import subprocess
from pathlib import Path

import pytest


def _git(repo: Path, *args: str) -> str:
    return subprocess.run(
        ["git", *args], cwd=repo, capture_output=True, text=True, check=True
    ).stdout.strip()


@pytest.fixture
def repo(tmp_path: Path) -> Path:
    """A fresh git repo on branch `main` with a couple of commits."""
    r = tmp_path / "sample"
    r.mkdir()
    _git(r, "init", "-q", "-b", "main")
    _git(r, "config", "user.email", "dev@example.com")
    _git(r, "config", "user.name", "Dev")

    (r / "README.md").write_text("# Sample\n\n## Install\n\n## Usage\n")
    _git(r, "add", "-A")
    _git(r, "commit", "-q", "-m", "feat: initial project scaffold")

    (r / "app.py").write_text("print('hi')\n")
    _git(r, "add", "-A")
    _git(r, "commit", "-q", "-m", "Added a thing without convention")  # a violation
    return r
