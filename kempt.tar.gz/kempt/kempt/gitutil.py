"""Thin wrappers around the `git` CLI.

Everything shells out to git rather than depending on a library, so kempt
has zero install-time dependencies and behaves exactly like the git the user
already has configured.
"""

from __future__ import annotations

import subprocess
from pathlib import Path


class GitError(RuntimeError):
    """Raised when a git invocation fails or no repository is found."""


def run(args: list[str], cwd: str | Path | None = None, check: bool = True) -> str:
    """Run `git <args>` and return stripped stdout."""
    proc = subprocess.run(
        ["git", *args],
        cwd=str(cwd) if cwd else None,
        capture_output=True,
        text=True,
    )
    if check and proc.returncode != 0:
        raise GitError(proc.stderr.strip() or f"git {' '.join(args)} failed")
    return proc.stdout.strip()


def repo_root(cwd: str | Path | None = None) -> Path:
    """Return the top-level directory of the repo containing cwd."""
    try:
        out = run(["rev-parse", "--show-toplevel"], cwd=cwd)
    except GitError as e:
        raise GitError("not inside a git repository") from e
    return Path(out)


def current_branch(cwd: str | Path | None = None) -> str:
    return run(["rev-parse", "--abbrev-ref", "HEAD"], cwd=cwd)


def default_branch(cwd: str | Path | None = None) -> str:
    """Best-effort guess at the repo's default branch."""
    for name in ("main", "master"):
        if run(["branch", "--list", name], cwd=cwd):
            return name
    # Fall back to current branch if neither exists.
    return current_branch(cwd=cwd)


def commits(rev_range: str | None = None, cwd: str | Path | None = None) -> list[dict]:
    """Return commits as dicts with sha, subject, author, iso-date.

    `rev_range` is any git range (e.g. 'v1.0..HEAD'); None means all history.
    """
    sep = "\x1f"  # unit separator — safe against commit text
    fmt = sep.join(["%H", "%s", "%an", "%aI"])
    args = ["log", f"--pretty=format:{fmt}"]
    if rev_range:
        args.append(rev_range)
    out = run(args, cwd=cwd)
    rows = []
    for line in out.splitlines():
        if not line:
            continue
        sha, subject, author, date = line.split(sep)
        rows.append({"sha": sha, "subject": subject, "author": author, "date": date})
    return rows


def last_tag(cwd: str | Path | None = None) -> str | None:
    out = run(["tag", "--sort=-creatordate"], cwd=cwd, check=False)
    tags = [t for t in out.splitlines() if t]
    return tags[0] if tags else None


def merged_branches(into: str, cwd: str | Path | None = None) -> list[str]:
    out = run(["branch", "--merged", into], cwd=cwd)
    names = []
    for line in out.splitlines():
        name = line.replace("*", "").strip()
        if name and not name.startswith("("):
            names.append(name)
    return names


def branch_last_commit_iso(branch: str, cwd: str | Path | None = None) -> str:
    return run(["log", "-1", "--format=%aI", branch], cwd=cwd)
