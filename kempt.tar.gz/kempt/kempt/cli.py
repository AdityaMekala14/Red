"""kempt command-line entry point."""

from __future__ import annotations

import argparse

from kempt import __version__
from kempt.commands import (
    lint_commits,
    stale_branches,
    health,
    changelog,
    toc,
)


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="kempt",
        description="A developer toolkit for keeping git repositories healthy.",
    )
    p.add_argument("--version", action="version", version=f"kempt {__version__}")
    p.add_argument("--cwd", default=None, help="Run against a repo in this directory")
    sub = p.add_subparsers(dest="command", required=True)

    for mod in (lint_commits, stale_branches, health, changelog, toc):
        mod.add_parser(sub)
    return p


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    return args.func(args)


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
