"""`kempt stale-branches` — find branches that are merged or long untouched."""

from __future__ import annotations

from datetime import datetime, timezone

from kempt import gitutil

PROTECTED = {"main", "master", "develop", "release"}


def find(days: int, cwd=None) -> dict:
    base = gitutil.default_branch(cwd=cwd)
    current = gitutil.current_branch(cwd=cwd)
    protected = PROTECTED | {base, current}

    merged = [b for b in gitutil.merged_branches(base, cwd=cwd) if b not in protected]

    now = datetime.now(timezone.utc)
    stale = []
    all_branches = [
        b.replace("*", "").strip()
        for b in gitutil.run(["branch"], cwd=cwd).splitlines()
    ]
    for b in all_branches:
        if b in protected or not b:
            continue
        iso = gitutil.branch_last_commit_iso(b, cwd=cwd)
        age = (now - datetime.fromisoformat(iso)).days
        if age >= days:
            stale.append((b, age))
    return {"merged": merged, "stale": sorted(stale, key=lambda x: -x[1]), "base": base}


def main(args) -> int:
    try:
        result = find(args.days, cwd=args.cwd)
    except gitutil.GitError as e:
        print(f"error: {e}")
        return 2

    merged, stale, base = result["merged"], result["stale"], result["base"]
    if not merged and not stale:
        print("No stale or merged branches to clean up. ✓")
        return 0

    if merged:
        print(f"Already merged into {base} (safe to delete):")
        for b in merged:
            print(f"  {b}")
        if args.prune:
            for b in merged:
                gitutil.run(["branch", "-d", b], cwd=args.cwd)
            print(f"\nDeleted {len(merged)} merged branch(es).")
    if stale:
        print(f"\nNo commits in {args.days}+ days:")
        for b, age in stale:
            print(f"  {b:30} {age} days")
    return 0


def add_parser(sub):
    p = sub.add_parser("stale-branches", help="List merged or long-untouched branches")
    p.add_argument("--days", type=int, default=90, help="Staleness threshold in days (default 90)")
    p.add_argument("--prune", action="store_true", help="Delete branches already merged into the base")
    p.set_defaults(func=main)
