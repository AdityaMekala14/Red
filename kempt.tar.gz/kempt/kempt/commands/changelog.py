"""`kempt changelog` — build a changelog from Conventional Commits."""

from __future__ import annotations

from kempt import gitutil
from kempt.commands.lint_commits import CONVENTIONAL

SECTIONS = [
    ("feat", "Features"),
    ("fix", "Bug Fixes"),
    ("perf", "Performance"),
    ("refactor", "Refactoring"),
    ("docs", "Documentation"),
]
TYPE_TO_TITLE = dict(SECTIONS)


def build(rev_range: str | None, cwd=None) -> str:
    groups: dict[str, list[str]] = {}
    breaking: list[str] = []

    for c in gitutil.commits(rev_range, cwd=cwd):
        m = CONVENTIONAL.match(c["subject"])
        if not m:
            continue
        desc = m.group("desc")
        scope = m.group("scope") or ""
        scope = scope.strip("()")
        entry = f"- {('**' + scope + ':** ') if scope else ''}{desc} ({c['sha'][:8]})"
        if m.group("breaking"):
            breaking.append(entry)
        groups.setdefault(m.group("type"), []).append(entry)

    lines = []
    if breaking:
        lines.append("### ⚠ BREAKING CHANGES\n")
        lines.extend(breaking)
        lines.append("")
    for typ, title in SECTIONS:
        if groups.get(typ):
            lines.append(f"### {title}\n")
            lines.extend(groups[typ])
            lines.append("")
    return "\n".join(lines).strip() or "_No conventional commits in range._"


def main(args) -> int:
    if args.range:
        rev = args.range
    else:
        tag = gitutil.last_tag(cwd=args.cwd)
        rev = f"{tag}..HEAD" if tag else None
    try:
        body = build(rev, cwd=args.cwd)
    except gitutil.GitError as e:
        print(f"error: {e}")
        return 2

    header = f"## {args.version}" if args.version else "## Unreleased"
    out = f"{header}\n\n{body}\n"
    print(out)
    return 0


def add_parser(sub):
    p = sub.add_parser("changelog", help="Generate a changelog from conventional commits")
    p.add_argument("--range", default=None, help="git range (default: since last tag)")
    p.add_argument("--version", default=None, help="Version header for the section")
    p.set_defaults(func=main)
