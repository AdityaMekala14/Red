"""`kempt health` — score a repo on common hygiene checks."""

from __future__ import annotations

from pathlib import Path

from kempt import gitutil

# (label, list of candidate paths, weight)
PRESENCE_CHECKS = [
    ("README", ["README.md", "README.rst", "README.txt", "README"], 2),
    ("LICENSE", ["LICENSE", "LICENSE.md", "LICENSE.txt", "COPYING"], 2),
    (".gitignore", [".gitignore"], 1),
    ("CI workflow", [".github/workflows", ".gitlab-ci.yml", ".circleci"], 2),
    ("Tests", ["tests", "test", "spec"], 2),
    ("Contributing guide", ["CONTRIBUTING.md", "CONTRIBUTING"], 1),
]

LARGE_FILE_BYTES = 5 * 1024 * 1024  # 5 MB


def check(cwd=None, large_bytes: int = LARGE_FILE_BYTES) -> dict:
    root = gitutil.repo_root(cwd=cwd)
    results = []
    score = 0
    total = 0
    for label, candidates, weight in PRESENCE_CHECKS:
        total += weight
        present = any((root / c).exists() for c in candidates)
        if present:
            score += weight
        results.append({"label": label, "present": present, "weight": weight})

    # Large tracked files
    tracked = gitutil.run(["ls-files"], cwd=root).splitlines()
    large = []
    for rel in tracked:
        fp = root / rel
        try:
            size = fp.stat().st_size
        except OSError:
            continue
        if size >= large_bytes:
            large.append((rel, size))

    return {
        "root": str(root),
        "checks": results,
        "large_files": sorted(large, key=lambda x: -x[1]),
        "score": score,
        "total": total,
    }


def _bar(pct: int, width: int = 20) -> str:
    filled = round(pct / 100 * width)
    return "█" * filled + "░" * (width - filled)


def main(args) -> int:
    try:
        r = check(cwd=args.cwd)
    except gitutil.GitError as e:
        print(f"error: {e}")
        return 2

    pct = round(r["score"] / r["total"] * 100) if r["total"] else 100
    print(f"Repo health: {pct}%  {_bar(pct)}  ({r['score']}/{r['total']})\n")
    for c in r["checks"]:
        mark = "✓" if c["present"] else "✗"
        print(f"  {mark} {c['label']}")
    if r["large_files"]:
        print("\n  Large tracked files (consider Git LFS or removal):")
        for rel, size in r["large_files"]:
            print(f"    {size / 1024 / 1024:6.1f} MB  {rel}")

    if args.fail_under and pct < args.fail_under:
        print(f"\nFAIL: health {pct}% < {args.fail_under}%")
        return 1
    return 0


def add_parser(sub):
    p = sub.add_parser("health", help="Score repository hygiene")
    p.add_argument("--fail-under", type=int, default=None, help="Exit non-zero below this score (for CI)")
    p.set_defaults(func=main)
