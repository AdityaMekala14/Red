"""`kempt toc` — generate or refresh a Markdown table of contents.

Inserts/updates a TOC between HTML markers so it can be re-run idempotently:

    <!-- kempt:toc -->
    ...generated list...
    <!-- kempt:toc-end -->
"""

from __future__ import annotations

import re
from pathlib import Path

START = "<!-- kempt:toc -->"
END = "<!-- kempt:toc-end -->"

HEADING = re.compile(r"^(#{1,6})\s+(.*?)\s*#*$")
CODE_FENCE = re.compile(r"^```")


def slugify(text: str) -> str:
    s = text.strip().lower()
    s = re.sub(r"[^\w\s-]", "", s)
    s = re.sub(r"\s+", "-", s)
    return s


def extract_headings(md: str, min_level: int = 2, max_level: int = 4) -> list[tuple[int, str]]:
    headings = []
    in_code = False
    for line in md.splitlines():
        if CODE_FENCE.match(line):
            in_code = not in_code
            continue
        if in_code:
            continue
        m = HEADING.match(line)
        if not m:
            continue
        level = len(m.group(1))
        if min_level <= level <= max_level:
            headings.append((level, m.group(2)))
    return headings


def render_toc(headings: list[tuple[int, str]], min_level: int) -> str:
    seen: dict[str, int] = {}
    lines = []
    for level, text in headings:
        slug = slugify(text)
        if slug in seen:
            seen[slug] += 1
            slug = f"{slug}-{seen[slug]}"
        else:
            seen[slug] = 0
        indent = "  " * (level - min_level)
        lines.append(f"{indent}- [{text}](#{slug})")
    return "\n".join(lines)


def apply_toc(md: str, toc: str) -> str:
    block = f"{START}\n{toc}\n{END}"
    if START in md and END in md:
        return re.sub(
            re.escape(START) + r".*?" + re.escape(END),
            block.replace("\\", "\\\\"),
            md,
            flags=re.DOTALL,
        )
    # No markers yet: insert after the first H1, else at the top.
    lines = md.splitlines()
    for i, line in enumerate(lines):
        if line.startswith("# "):
            lines.insert(i + 1, "\n" + block + "\n")
            return "\n".join(lines)
    return block + "\n\n" + md


def main(args) -> int:
    path = Path(args.file)
    if not path.exists():
        print(f"error: {path} not found")
        return 2
    md = path.read_text()
    headings = extract_headings(md, args.min_level, args.max_level)
    toc = render_toc(headings, args.min_level)
    updated = apply_toc(md, toc)

    if args.check:
        if updated != md:
            print("TOC is out of date. Run without --check to update.")
            return 1
        print("TOC is up to date. ✓")
        return 0

    if args.write:
        path.write_text(updated)
        print(f"Updated TOC in {path} ({len(headings)} headings).")
    else:
        print(toc)
    return 0


def add_parser(sub):
    p = sub.add_parser("toc", help="Generate/update a Markdown table of contents")
    p.add_argument("file", help="Markdown file (e.g. README.md)")
    p.add_argument("--write", action="store_true", help="Write changes back into the file")
    p.add_argument("--check", action="store_true", help="Exit non-zero if the TOC is stale (for CI)")
    p.add_argument("--min-level", type=int, default=2, help="Shallowest heading level (default 2)")
    p.add_argument("--max-level", type=int, default=4, help="Deepest heading level (default 4)")
    p.set_defaults(func=main)
