"""`kempt lint-commits` — check commit subjects against Conventional Commits."""

from __future__ import annotations

import re

from kempt import gitutil

# type(scope)!: description
CONVENTIONAL = re.compile(
    r"^(?P<type>feat|fix|docs|style|refactor|perf|test|build|ci|chore|revert)"
    r"(?P<scope>\([\w\-./ ]+\))?(?P<breaking>!)?: (?P<desc>.+)$"
)

MERGE = re.compile(r"^(Merge |Revert )")


def lint(rev_range: str | None, cwd=None, max_len: int = 72) -> list[tuple[str, str, str]]:
    """Return a list of (sha, subject, reason) for each violating commit."""
    violations = []
    for c in gitutil.commits(rev_range, cwd=cwd):
        subject = c["subject"]
        if MERGE.match(subject):
            continue  # merge/revert auto-messages are exempt
        m = CONVENTIONAL.match(subject)
        if not m:
            violations.append((c["sha"][:8], subject, "does not match type(scope): description"))
            continue
        if len(subject) > max_len:
            violations.append((c["sha"][:8], subject, f"subject exceeds {max_len} chars"))
        elif m.group("desc")[0].isupper():
            violations.append((c["sha"][:8], subject, "description should start lowercase"))
    return violations


def main(args) -> int:
    rev = args.range or f"{gitutil.default_branch(args.cwd)}..HEAD" if not args.all else None
    try:
        violations = lint(rev, cwd=args.cwd, max_len=args.max_len)
    except gitutil.GitError as e:
        print(f"error: {e}")
        return 2

    if not violations:
        print("All commit subjects follow Conventional Commits. ✓")
        return 0

    print(f"{len(violations)} commit(s) need attention:\n")
    for sha, subject, reason in violations:
        print(f"  {sha}  {reason}")
        print(f"            {subject}")
    return 1


def add_parser(sub):
    p = sub.add_parser("lint-commits", help="Lint commit subjects (Conventional Commits)")
    p.add_argument("--range", default=None, help="git revision range (default: <default-branch>..HEAD)")
    p.add_argument("--all", action="store_true", help="Lint the entire history")
    p.add_argument("--max-len", type=int, default=72, help="Max subject length (default 72)")
    p.set_defaults(func=main)
