"""kempt — a developer toolkit for keeping git repositories healthy.

A single CLI with focused sub-commands for the chores every repo accumulates:
linting commit messages, pruning stale branches, scoring repo health,
generating a changelog, and keeping a README table of contents in sync.

Pure standard library. No network, no telemetry, no third-party data.
"""

__version__ = "0.1.0"

__all__ = ["__version__"]
