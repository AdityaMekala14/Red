# kempt usage

All commands run against the git repo in the current directory (or `--cwd PATH`).

## lint-commits

Check commit subjects against Conventional Commits.

```bash
kempt lint-commits                 # <default-branch>..HEAD
kempt lint-commits --all           # entire history
kempt lint-commits --max-len 50
```

Exit code is non-zero when violations are found, so it drops straight into a
pre-push hook or CI.

## stale-branches

```bash
kempt stale-branches               # merged + branches idle 90+ days
kempt stale-branches --days 30
kempt stale-branches --prune       # delete branches already merged into base
```

`--prune` only removes branches git considers fully merged (`git branch -d`),
so unmerged work is never touched.

## health

```bash
kempt health                       # scored hygiene report
kempt health --fail-under 60       # CI gate
```

Checks for README, LICENSE, .gitignore, CI config, tests, a contributing
guide, and flags large tracked files.

## changelog

```bash
kempt changelog                    # since the most recent tag
kempt changelog --version 1.2.0
kempt changelog --range v1.0.0..HEAD
```

Groups conventional commits into Features / Fixes / etc. and surfaces
`BREAKING CHANGE` (`!`) entries at the top.

## toc

```bash
kempt toc README.md                # print a table of contents
kempt toc README.md --write        # insert/update it in place
kempt toc README.md --check        # CI: fail if stale
```

The TOC is written between `<!-- kempt:toc -->` markers, so re-running is
idempotent.
